@echo off
chcp 65001 >nul
set "BROWSER="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER (
  echo Chrome 또는 Edge 를 찾을 수 없어요. Chrome 을 설치해 주세요.
  pause
  exit /b
)
set "P=%~dp0index.html"
set "P=%P:\=/%"
set "P=%P: =%20%"
set "URL=file:///%P%"
set "OPT=--kiosk --allow-file-access-from-files --autoplay-policy=no-user-gesture-required --no-first-run --no-default-browser-check --disable-translate --disable-session-crashed-bubble --disable-infobars --overscroll-history-navigation=0"
rem 모니터 1대: 전체 화면(키오스크)으로 열기. 끝내려면 Alt+F4
start "" "%BROWSER%" %OPT% --user-data-dir="%TEMP%\cove-profile-1" "%URL%"
