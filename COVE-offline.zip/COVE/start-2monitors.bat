@echo off
chcp 65001 >nul
set "BROWSER="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER (
  echo Chrome 또는 Edge 를 찾을 수 없어요. Chrome 을 설치해 주세요.
  pause
  exit /b
)
set "P=%~dp0index.html"
set "P=%P:\=/%"
set "P=%P: =%20%"
set "URL=file:///%P%"
set "OPT=--kiosk --allow-file-access-from-files --autoplay-policy=no-user-gesture-required --no-first-run --no-default-browser-check --disable-translate --disable-session-crashed-bubble --disable-infobars --overscroll-history-navigation=0"
rem 모니터 2대: 각각 다른 창으로 열기 (모니터 1 = 왼쪽, 모니터 2 = 오른쪽, 각 1920x1080 가정)
rem  모니터 배치가 다르면 아래 1920 숫자를 바꿔 주세요. 끝내려면 각 화면에서 Alt+F4
start "" "%BROWSER%" %OPT% --user-data-dir="%TEMP%\cove-profile-1" --window-position=0,0 "%URL%"
timeout /t 3 /nobreak >nul
start "" "%BROWSER%" %OPT% --user-data-dir="%TEMP%\cove-profile-2" --window-position=1920,0 "%URL%"
